import paho.mqtt.client as mqtt
import asyncio
import json

try:
    import troTHU.runtime_context as ctx
except ImportError:
    import runtime_context as ctx

MQTT_BROKER = "broker.emqx.io"
MQTT_PORT = 1883

_client = None
_loop = None

def on_connect(client, userdata, flags, rc):
    channel = ctx.CONFIG.get("mqtt_channel")
    if channel and rc == 0:
        topic = f"tronclass/qr_relay/{channel}"
        client.subscribe(topic)
        ctx.log_print(f"✅ 已連線至雲端廣播站，正在監聽專屬頻道: {channel}")
    elif rc != 0:
        ctx.log_print(f"⚠️ MQTT 連線失敗，回傳碼: {rc}")

def on_message(client, userdata, msg):
    payload = msg.payload.decode('utf-8')
    ctx.log_print(f"📡 收到雲端廣播 QR: {payload[:30]}...")
    
    # Try to validate json
    try:
        data = json.loads(payload)
        if "rollcallId" not in data and "rollcall_id" not in data:
            ctx.log_print("⚠️ 收到的廣播格式不正確，略過。")
            return
    except json.JSONDecodeError:
        ctx.log_print("⚠️ 收到的廣播不是合法的 JSON 格式，略過。")
        return

    if _loop and not _loop.is_closed():
        # Dispatch group QR submission to main asyncio loop
        ctx.log_print("🚀 正在為所有帳號執行 QR 代點名...")
        asyncio.run_coroutine_threadsafe(
            ctx.qr_fanout_command(payload),
            _loop
        )

def start_mqtt_relay(loop: asyncio.AbstractEventLoop):
    global _client, _loop
    _loop = loop
    
    channel = ctx.CONFIG.get("mqtt_channel")
    if not channel:
        return
        
    _client = mqtt.Client(client_id="tron_bot_" + str(id(loop))[:6])
    _client.on_connect = on_connect
    _client.on_message = on_message
    
    try:
        ctx.log_print(f"啟動 MQTT 雲端廣播接收器 (頻道: {channel})...")
        _client.connect(MQTT_BROKER, MQTT_PORT, 60)
        _client.loop_start() # Starts a background thread
    except Exception as e:
        ctx.log_print(f"⚠️ 無法連線至 MQTT Broker: {e}")

def stop_mqtt_relay():
    if _client:
        _client.loop_stop()
        _client.disconnect()
